﻿namespace CursoWindowsForms
{
    partial class Frm_CadastroCliente_UC
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_Profissao = new System.Windows.Forms.TextBox();
            this.Lbl_Profissao = new System.Windows.Forms.Label();
            this.Txt_RendaFamiliar = new System.Windows.Forms.TextBox();
            this.Lbl_RendaFamiliar = new System.Windows.Forms.Label();
            this.Txt_Telefone = new System.Windows.Forms.TextBox();
            this.Lbl_Telefone = new System.Windows.Forms.Label();
            this.Txt_Estado = new System.Windows.Forms.TextBox();
            this.Lbl_Estado = new System.Windows.Forms.Label();
            this.Txt_Bairro = new System.Windows.Forms.TextBox();
            this.Lbl_Bairro = new System.Windows.Forms.Label();
            this.Txt_Complemento = new System.Windows.Forms.TextBox();
            this.Lbl_Complemento = new System.Windows.Forms.Label();
            this.Txt_Logradouro = new System.Windows.Forms.TextBox();
            this.Lbl_Logradouro = new System.Windows.Forms.Label();
            this.Txt_CEP = new System.Windows.Forms.TextBox();
            this.Lbl_CEP = new System.Windows.Forms.Label();
            this.Txt_CPF = new System.Windows.Forms.TextBox();
            this.Lbl_CPF = new System.Windows.Forms.Label();
            this.Txt_NomeMae = new System.Windows.Forms.TextBox();
            this.Lbl_NomeMae = new System.Windows.Forms.Label();
            this.Txt_NomePai = new System.Windows.Forms.TextBox();
            this.Lbl_NomePai = new System.Windows.Forms.Label();
            this.Txt_NomeCliente = new System.Windows.Forms.TextBox();
            this.Lbl_NomeCliente = new System.Windows.Forms.Label();
            this.Txt_Genero = new System.Windows.Forms.TextBox();
            this.Lbl_Genero = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Txt_Profissao
            // 
            this.Txt_Profissao.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Profissao.Location = new System.Drawing.Point(347, 350);
            this.Txt_Profissao.Name = "Txt_Profissao";
            this.Txt_Profissao.Size = new System.Drawing.Size(451, 20);
            this.Txt_Profissao.TabIndex = 47;
            // 
            // Lbl_Profissao
            // 
            this.Lbl_Profissao.AutoSize = true;
            this.Lbl_Profissao.Location = new System.Drawing.Point(345, 334);
            this.Lbl_Profissao.Name = "Lbl_Profissao";
            this.Lbl_Profissao.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Profissao.TabIndex = 46;
            this.Lbl_Profissao.Text = "Label1";
            // 
            // Txt_RendaFamiliar
            // 
            this.Txt_RendaFamiliar.Location = new System.Drawing.Point(12, 390);
            this.Txt_RendaFamiliar.Name = "Txt_RendaFamiliar";
            this.Txt_RendaFamiliar.Size = new System.Drawing.Size(328, 20);
            this.Txt_RendaFamiliar.TabIndex = 45;
            // 
            // Lbl_RendaFamiliar
            // 
            this.Lbl_RendaFamiliar.AutoSize = true;
            this.Lbl_RendaFamiliar.Location = new System.Drawing.Point(12, 374);
            this.Lbl_RendaFamiliar.Name = "Lbl_RendaFamiliar";
            this.Lbl_RendaFamiliar.Size = new System.Drawing.Size(39, 13);
            this.Lbl_RendaFamiliar.TabIndex = 44;
            this.Lbl_RendaFamiliar.Text = "Label1";
            // 
            // Txt_Telefone
            // 
            this.Txt_Telefone.Location = new System.Drawing.Point(12, 350);
            this.Txt_Telefone.Name = "Txt_Telefone";
            this.Txt_Telefone.Size = new System.Drawing.Size(328, 20);
            this.Txt_Telefone.TabIndex = 43;
            // 
            // Lbl_Telefone
            // 
            this.Lbl_Telefone.AutoSize = true;
            this.Lbl_Telefone.Location = new System.Drawing.Point(12, 334);
            this.Lbl_Telefone.Name = "Lbl_Telefone";
            this.Lbl_Telefone.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Telefone.TabIndex = 42;
            this.Lbl_Telefone.Text = "Label1";
            // 
            // Txt_Estado
            // 
            this.Txt_Estado.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Estado.Location = new System.Drawing.Point(667, 310);
            this.Txt_Estado.Name = "Txt_Estado";
            this.Txt_Estado.Size = new System.Drawing.Size(132, 20);
            this.Txt_Estado.TabIndex = 41;
            // 
            // Lbl_Estado
            // 
            this.Lbl_Estado.AutoSize = true;
            this.Lbl_Estado.Location = new System.Drawing.Point(664, 294);
            this.Lbl_Estado.Name = "Lbl_Estado";
            this.Lbl_Estado.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Estado.TabIndex = 40;
            this.Lbl_Estado.Text = "Label1";
            // 
            // Txt_Bairro
            // 
            this.Txt_Bairro.Location = new System.Drawing.Point(347, 310);
            this.Txt_Bairro.Name = "Txt_Bairro";
            this.Txt_Bairro.Size = new System.Drawing.Size(311, 20);
            this.Txt_Bairro.TabIndex = 39;
            // 
            // Lbl_Bairro
            // 
            this.Lbl_Bairro.AutoSize = true;
            this.Lbl_Bairro.Location = new System.Drawing.Point(345, 294);
            this.Lbl_Bairro.Name = "Lbl_Bairro";
            this.Lbl_Bairro.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Bairro.TabIndex = 38;
            this.Lbl_Bairro.Text = "Label1";
            // 
            // Txt_Complemento
            // 
            this.Txt_Complemento.Location = new System.Drawing.Point(12, 310);
            this.Txt_Complemento.Name = "Txt_Complemento";
            this.Txt_Complemento.Size = new System.Drawing.Size(328, 20);
            this.Txt_Complemento.TabIndex = 37;
            // 
            // Lbl_Complemento
            // 
            this.Lbl_Complemento.AutoSize = true;
            this.Lbl_Complemento.Location = new System.Drawing.Point(12, 294);
            this.Lbl_Complemento.Name = "Lbl_Complemento";
            this.Lbl_Complemento.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Complemento.TabIndex = 36;
            this.Lbl_Complemento.Text = "Label1";
            // 
            // Txt_Logradouro
            // 
            this.Txt_Logradouro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Logradouro.Location = new System.Drawing.Point(12, 270);
            this.Txt_Logradouro.Name = "Txt_Logradouro";
            this.Txt_Logradouro.Size = new System.Drawing.Size(787, 20);
            this.Txt_Logradouro.TabIndex = 35;
            // 
            // Lbl_Logradouro
            // 
            this.Lbl_Logradouro.AutoSize = true;
            this.Lbl_Logradouro.Location = new System.Drawing.Point(12, 254);
            this.Lbl_Logradouro.Name = "Lbl_Logradouro";
            this.Lbl_Logradouro.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Logradouro.TabIndex = 34;
            this.Lbl_Logradouro.Text = "Label1";
            // 
            // Txt_CEP
            // 
            this.Txt_CEP.Location = new System.Drawing.Point(12, 230);
            this.Txt_CEP.Name = "Txt_CEP";
            this.Txt_CEP.Size = new System.Drawing.Size(271, 20);
            this.Txt_CEP.TabIndex = 33;
            // 
            // Lbl_CEP
            // 
            this.Lbl_CEP.AutoSize = true;
            this.Lbl_CEP.Location = new System.Drawing.Point(12, 214);
            this.Lbl_CEP.Name = "Lbl_CEP";
            this.Lbl_CEP.Size = new System.Drawing.Size(39, 13);
            this.Lbl_CEP.TabIndex = 32;
            this.Lbl_CEP.Text = "Label1";
            // 
            // Txt_CPF
            // 
            this.Txt_CPF.Location = new System.Drawing.Point(12, 30);
            this.Txt_CPF.Name = "Txt_CPF";
            this.Txt_CPF.Size = new System.Drawing.Size(268, 20);
            this.Txt_CPF.TabIndex = 31;
            // 
            // Lbl_CPF
            // 
            this.Lbl_CPF.AutoSize = true;
            this.Lbl_CPF.Location = new System.Drawing.Point(12, 14);
            this.Lbl_CPF.Name = "Lbl_CPF";
            this.Lbl_CPF.Size = new System.Drawing.Size(39, 13);
            this.Lbl_CPF.TabIndex = 30;
            this.Lbl_CPF.Text = "Label1";
            // 
            // Txt_NomeMae
            // 
            this.Txt_NomeMae.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_NomeMae.Location = new System.Drawing.Point(12, 150);
            this.Txt_NomeMae.Name = "Txt_NomeMae";
            this.Txt_NomeMae.Size = new System.Drawing.Size(787, 20);
            this.Txt_NomeMae.TabIndex = 29;
            // 
            // Lbl_NomeMae
            // 
            this.Lbl_NomeMae.AutoSize = true;
            this.Lbl_NomeMae.Location = new System.Drawing.Point(12, 134);
            this.Lbl_NomeMae.Name = "Lbl_NomeMae";
            this.Lbl_NomeMae.Size = new System.Drawing.Size(39, 13);
            this.Lbl_NomeMae.TabIndex = 28;
            this.Lbl_NomeMae.Text = "Label1";
            // 
            // Txt_NomePai
            // 
            this.Txt_NomePai.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_NomePai.Location = new System.Drawing.Point(12, 110);
            this.Txt_NomePai.Name = "Txt_NomePai";
            this.Txt_NomePai.Size = new System.Drawing.Size(787, 20);
            this.Txt_NomePai.TabIndex = 27;
            // 
            // Lbl_NomePai
            // 
            this.Lbl_NomePai.AutoSize = true;
            this.Lbl_NomePai.Location = new System.Drawing.Point(12, 94);
            this.Lbl_NomePai.Name = "Lbl_NomePai";
            this.Lbl_NomePai.Size = new System.Drawing.Size(39, 13);
            this.Lbl_NomePai.TabIndex = 26;
            this.Lbl_NomePai.Text = "Label1";
            // 
            // Txt_NomeCliente
            // 
            this.Txt_NomeCliente.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_NomeCliente.Location = new System.Drawing.Point(12, 70);
            this.Txt_NomeCliente.Name = "Txt_NomeCliente";
            this.Txt_NomeCliente.Size = new System.Drawing.Size(787, 20);
            this.Txt_NomeCliente.TabIndex = 25;
            // 
            // Lbl_NomeCliente
            // 
            this.Lbl_NomeCliente.AutoSize = true;
            this.Lbl_NomeCliente.Location = new System.Drawing.Point(12, 54);
            this.Lbl_NomeCliente.Name = "Lbl_NomeCliente";
            this.Lbl_NomeCliente.Size = new System.Drawing.Size(39, 13);
            this.Lbl_NomeCliente.TabIndex = 24;
            this.Lbl_NomeCliente.Text = "Label1";
            // 
            // Txt_Genero
            // 
            this.Txt_Genero.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Genero.Location = new System.Drawing.Point(12, 190);
            this.Txt_Genero.Name = "Txt_Genero";
            this.Txt_Genero.Size = new System.Drawing.Size(271, 20);
            this.Txt_Genero.TabIndex = 49;
            // 
            // Lbl_Genero
            // 
            this.Lbl_Genero.AutoSize = true;
            this.Lbl_Genero.Location = new System.Drawing.Point(12, 174);
            this.Lbl_Genero.Name = "Lbl_Genero";
            this.Lbl_Genero.Size = new System.Drawing.Size(39, 13);
            this.Lbl_Genero.TabIndex = 48;
            this.Lbl_Genero.Text = "Label1";
            // 
            // Frm_CadastroCliente_UC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Txt_Genero);
            this.Controls.Add(this.Lbl_Genero);
            this.Controls.Add(this.Txt_Profissao);
            this.Controls.Add(this.Lbl_Profissao);
            this.Controls.Add(this.Txt_RendaFamiliar);
            this.Controls.Add(this.Lbl_RendaFamiliar);
            this.Controls.Add(this.Txt_Telefone);
            this.Controls.Add(this.Lbl_Telefone);
            this.Controls.Add(this.Txt_Estado);
            this.Controls.Add(this.Lbl_Estado);
            this.Controls.Add(this.Txt_Bairro);
            this.Controls.Add(this.Lbl_Bairro);
            this.Controls.Add(this.Txt_Complemento);
            this.Controls.Add(this.Lbl_Complemento);
            this.Controls.Add(this.Txt_Logradouro);
            this.Controls.Add(this.Lbl_Logradouro);
            this.Controls.Add(this.Txt_CEP);
            this.Controls.Add(this.Lbl_CEP);
            this.Controls.Add(this.Txt_CPF);
            this.Controls.Add(this.Lbl_CPF);
            this.Controls.Add(this.Txt_NomeMae);
            this.Controls.Add(this.Lbl_NomeMae);
            this.Controls.Add(this.Txt_NomePai);
            this.Controls.Add(this.Lbl_NomePai);
            this.Controls.Add(this.Txt_NomeCliente);
            this.Controls.Add(this.Lbl_NomeCliente);
            this.Name = "Frm_CadastroCliente_UC";
            this.Size = new System.Drawing.Size(806, 463);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txt_Profissao;
        private System.Windows.Forms.Label Lbl_Profissao;
        private System.Windows.Forms.TextBox Txt_RendaFamiliar;
        private System.Windows.Forms.Label Lbl_RendaFamiliar;
        private System.Windows.Forms.TextBox Txt_Telefone;
        private System.Windows.Forms.Label Lbl_Telefone;
        private System.Windows.Forms.TextBox Txt_Estado;
        private System.Windows.Forms.Label Lbl_Estado;
        private System.Windows.Forms.TextBox Txt_Bairro;
        private System.Windows.Forms.Label Lbl_Bairro;
        private System.Windows.Forms.TextBox Txt_Complemento;
        private System.Windows.Forms.Label Lbl_Complemento;
        private System.Windows.Forms.TextBox Txt_Logradouro;
        private System.Windows.Forms.Label Lbl_Logradouro;
        private System.Windows.Forms.TextBox Txt_CEP;
        private System.Windows.Forms.Label Lbl_CEP;
        private System.Windows.Forms.TextBox Txt_CPF;
        private System.Windows.Forms.Label Lbl_CPF;
        private System.Windows.Forms.TextBox Txt_NomeMae;
        private System.Windows.Forms.Label Lbl_NomeMae;
        private System.Windows.Forms.TextBox Txt_NomePai;
        private System.Windows.Forms.Label Lbl_NomePai;
        private System.Windows.Forms.TextBox Txt_NomeCliente;
        private System.Windows.Forms.Label Lbl_NomeCliente;
        private System.Windows.Forms.TextBox Txt_Genero;
        private System.Windows.Forms.Label Lbl_Genero;
    }
}
